<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0036)http://news.cqham.ru/ads/adframe.php -->
<HTML><HEAD><TITLE>www.dxsoft.com</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-1251">
<META content="MSHTML 6.00.2600.0" name=GENERATOR></HEAD>
<BODY style="BACKGROUND-COLOR: transparent" leftMargin=0 topMargin=0 
marginheight="0" marginwidth="0"><A 
href="http://news.cqham.ru/ads/adclick.php?bannerid=13&amp;zoneid=0&amp;source=&amp;dest=http%3A%2F%2Fwww.dxsoft.com%2Fru%2F" 
target=_top><IMG title=www.dxsoft.com height=60 alt=www.dxsoft.com 
src="adframe.files/dxsoft.gif" width=468 border=0></A>
<DIV id=beacon_13 
style="LEFT: 0px; VISIBILITY: hidden; POSITION: absolute; TOP: 0px"><IMG 
style="WIDTH: 0px; HEIGHT: 0px" height=0 alt="" src="adframe.files/adlog.gif" 
width=0></DIV></BODY></HTML>

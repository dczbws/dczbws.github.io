pl="";sl="1.1";
if((n==1) && (bv >= 300)) 
{ for(var i = 0; i < nv.plugins.length; i++)
  pl += nv.plugins[i].name+":"; 
}
j = (navigator.javaEnabled() ? "Y" : "N");h=1
d.write("<script language=javascript1.2>");
d.write("sl=\"1.2\";s=screen;wh=s.width+'x'+s.height;px=(n==0)?screen.colorDepth:screen.pixelDepth;z+=\"&wh=\"+wh+\"&px=\"+px;");
d.write("</"+"script>");
d.write("<script language=javascript1.3>");
d.write("sl=\"1.3\";");
d.write("</"+"script>"); 
y="<a href='http://"+u+"/cnt?f=3&p="+p+"&rn="+rn+"' target=_blank><img src='http://"+u+"/cnt?"+z;
y+="&j="+j+"&sl="+sl+"&r="+r+"&fr="+fr+"&pg="+escape(window.location.href)+"&pl="+escape(pl);
y+="' border=0 "+sz+" alt='SpyLOG'></a>"; d.write(y);
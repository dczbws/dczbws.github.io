TAudio v4.1

See the Windows help file (audio.hlp) for info about how to use the component and version changes

Comments: Hakan Bergzen, hakan_bergzen@hotmail.com

There are two DCR files, since Borland seems to have changed the component resource format between versions.
One for the 16bit version (Delphi1) and one for the 32bit version (Delphi2 and higher). 
Just change the name of the one you want to audio.dcr

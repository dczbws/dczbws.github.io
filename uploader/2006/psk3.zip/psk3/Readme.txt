Readme.txt for AnalogMeter.pas

See AnalogMeter.txt for a description of the component.

Testing the component: 
I have included a test-project which creates the component at runtime, so you don't have to install it.

Installing: As always (Delphi 3.0:) Components/Install, select AnalogMeter.pas.

Have fun,
hannes
(hannes.breuer@talknet.de)
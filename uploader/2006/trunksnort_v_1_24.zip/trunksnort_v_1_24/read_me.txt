Fehlverhalten / Known Bug

- Gelegentlich kommt es bei einigen Rechnern zu Problemen mit der
  Scannersteuerung �ber die RS-232 Schnittstelle wenn das Programm
  gestartet wird. 
  Abhilfe:
  Programm stoppen (strg-c), mit einem anderen Programm auf die 
  Schnittstelle zugreifen (Hyperterm oder so), und danach 
  Trunksnort wieder starten.
  So funktionierte es bisher beim Auftreten dieses Problems
  immer.


* Sometimes it could happen that the Software seems not to
  Control the Scanner via RS-232.
  Try this:
  Stopp TrunkSnort (ctrl-c), use another Program like Hyperterm
  or so to use the RS-232, and after that, start again
  TrunkSnort.
  That helps is any cases of that error I saw.


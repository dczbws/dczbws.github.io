
#ifndef MPT1327_H
#define MPT1327_H

#include <stdlib.h>


#define MPT1327_SYNC 0xc4d7
#define MPT1327_SYNT 0x3b28

typedef struct {
    unsigned short codeword[4];
    unsigned short fcs;
    unsigned char cnt;
    unsigned char state;
} mpt1327_t;

void mpt1327_setup(void);
void mpt1327(unsigned char bit, mpt1327_t *state);
void setfreq(double qrg);

#endif /* MPT1327_H */

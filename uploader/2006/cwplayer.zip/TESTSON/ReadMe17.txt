

 =========================
    CW_Player V1.7
 =========================
 Written by G. Rivat F6DQM
 =========================

 This simple freeware program generates Morse caracters and Q codes.
 It needs a sound card and Win95.
 It is so easy to use that it needs no Help file. Only hints are displayed
 when the mouse points on controls or boxes.

 Windows features such as Copy (Control-C) and Paste (Control-V) can be used
 to select part of a random serie and replay it by copying in the Text box or
 save it in a file by using the Paste with your favorite editor. (Note that
 the TEXT window accepts only ONE record so, only ONE line of an ASCII file
 can be pasted in this window.)

 This program is mainly intended to be downloaded by WEB surfers from 
 radioamateur sites.
 Its purpose is to initiate non-radioamateur people with Morse code and help
 him to join the radioamateur community.

 So, don't hesitate to propose this software to your visitors if you manage
 a radioamateur WEB site.

 However, this program may also be used for your own morse 
 training, for CW instructors or for training on the air by connecting one
 of the output of your sound card to the audio input of your 
 SSB or FM transceiver.

 In the same way, you may also call or answer a CW call by typing your text
 in the text box or playing a prepared file. Be aware that it does not 
 decode Morse signals but the ear is certainly the most powerfull CW decoder.


 Version 1.5 features :
 ======================
 - more Q codes
 - choice between English and French Language.

 The language may be choosen in the command line by typing the following 
 parameter : /e for English, /f for French. If no parameter, CW_Player
 starts with English.
 For example, to start in French, type c:\cw_player.exe /f ,assuming the
 executable file is named cw_player.
 BE AWARE that under  Win95, when using the Execute command or
 creating a short, the command line is displayed between double quotes.
 Then, the parameter must be typed AFTER the last double quote :
      "C:\CW_Player.EXE" /f

 Version 1.6 features :
 ======================
 - minimum speed at 10 words/mn
 - correction of a system error that appears in a very particuliar case. 


 Version 1.7 features :
 ======================
 - possibility to open and play any ASCII file of  your system.
 Authorized extensions are .TXT, .WRI, .RTF, .CWP (for CWPlayer).
 Other files may be played if renamed with an authorized extension
 but the result may be unexpected.
 Only morse caracters are played.
 An file may be modified when opened or fully played. Modifications
 are temporary and never saved on your disk.
 A stopped file is resumed where it was stopped. When stopped before
 the end, a file cannot be modified. If you want to modify it, you
 have to reopen it or play it until the end.
 It you want to restart it, you have to reopen it. 

 This Readme.txt file that you are reading may be opened on-line for
 reference (or execution !).

 - Inhibition of all choices whenever a file, a text or random series
 are being executed. The STOP button has to be depressed to recover choices 
 and controls.

 - Supplying of PTT command signals to your TRX from a COM port.
 If a valid COM port is chosen, the DTR (pin 4)  and RTS (pin 7) 
 signals of the relevant serial connector are set HIGH (+12V/ground pin 5)
 whenever caracters are played.
 The LED "On air" lits when the COM port is active.
 If no COM port or an unvalid COM port has been chosen, the DTR 
 and RTS remains LOW (-12V) and LED unlit.
 A COM port may be chosen when starting CW_Player with parameter /COMx 
 in the command line.
 Be sure that the serial connector  you want to use is really affected
 to the chosen COM port (to be verified in your setup configuration).
 Choosing a non-valid COM port will generate a non-blocking error.
  
 Note that DTR and RTS are high when active. So they cannot be directly
 connected to the PTT line of TRX which requires grounding to switch
 on transmit.
 A circuit example is drawn in file PC_TX.BMP. The scheme assumes that a
 positive voltage is present on your TX PTT terminal when in RX mode. In
 old valve TRX, negative voltage appears in RX mode on the KEY terminal.
 The scheme has to be modified consequently.

 -Suppression of "clicks" which appeared in version 1.6.

 Enjoy CW trafic and make others enjoy it.

 G. RIVAT
 F6DQM@F6KFV.FRPA.FRA.EU (packet)




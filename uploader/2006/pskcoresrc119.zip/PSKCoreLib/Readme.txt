========================================================================
       STATIC LIBRARY : PSKCoreLib
========================================================================


AppWizard has created this PSKCoreLib library for you.  

This file contains a summary of what you will find in each of the files that
make up your PSKCoreLib application.

/////////////////////////////////////////////////////////////////////////////

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named PSKCoreLib.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
The compiler and linker switches have been modified to support MFC. Using the
MFC ClassWizard with this project requires that you add several files to the 
project, including "resource.h", "PSKCoreLib.rc" and a "PSKCoreLib.h" that 
includes resource.h. If you add an rc file to a static library, you may 
experience difficulties due to the limitation that only one rc file may be 
present in a Dll or Exe. This problem may be overcome by including the 
library's .rc file into the parent project's .rc file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
